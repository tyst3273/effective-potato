This archive contains all the input files from the Appendix of the Tutorial
"Computing Bulk Phase Vibrational Spectra with CP2k and TRAVIS".

The tutorial PDF file as well as this archive can be freely downloaded from

    https://brehm-research.de/spectroscopy

The input files are named corresponding to the Appendix sections in which
they appear.

(c) Martin Brehm, 2018

